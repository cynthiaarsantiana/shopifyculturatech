<?php
  return [
      'environment' => 'development',
      'display_errors' => true,
      'error_reporting' => E_ALL,
      'timezone' => 'Asia/Jakarta'
  ];
?>
